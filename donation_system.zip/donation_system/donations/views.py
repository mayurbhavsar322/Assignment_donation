from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import UserProfile, Donation, PaymentHistory

@login_required
def user_profile(request):
    user_profile = UserProfile.objects.get(user=request.user)
    return render(request, 'profile.html', {'user_profile': user_profile})

@login_required
def donate(request):
    if request.method == 'POST':
        amount = request.POST.get('amount')
        Donation.objects.create(user=request.user, amount=amount)
        messages.success(request, 'Thank you for your donation!')
        return redirect('donate')
    return render(request, 'donate.html')

@login_required
def payment_history(request):
    payment_history = PaymentHistory.objects.filter(user=request.user)
    return render(request, 'payment_history.html', {'payment_history': payment_history})


